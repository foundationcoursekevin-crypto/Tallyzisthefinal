# Build the Tally .exe on GitHub (works from a phone)

1. Put `Tally-complete.zip` in your repository (front page > Add file > Upload files > Commit).
2. Create `.github/workflows/build.yml` (front page > Add file > Create new file; type the full name; paste the text from this zip's `.github/workflows/build.yml`).
3. Actions > Build Windows EXE > Run workflow. Wait 4 to 8 minutes for the green tick.
4. Open the run, scroll to Artifacts, tap Tally-Windows. It is a zip with `Tally-Setup-0.1.0.exe` (installer) and `Tally-Portable-0.1.0.exe` (no install).
5. Windows may say "Windows protected your PC" because the exe is not signed: More info > Run anyway.

The logo is `build/icon.png` (1024 x 1024). Replace that file to change the icon.
